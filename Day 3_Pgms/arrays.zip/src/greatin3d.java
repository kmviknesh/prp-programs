
public class greatin3d {

	public static void main(String[] args) {

      int[][] a = new int[3][3];
      

	}

}
