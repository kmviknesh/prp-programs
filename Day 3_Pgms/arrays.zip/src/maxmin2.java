// second maximum and minimum

import java.util.Scanner;

public class maxmin2 {

	public static void main(String[] args) {
		 int a[]=new int[10];
         int min,max, min2,max2;
         Scanner s= new Scanner(System.in);
         System.out.println("Enter 10 elements: ");
         for(int i=0;i<10;i++)
        	 a[i] = s.nextInt();
          max = a[0];
          min=max2=min2=max;
         for(int i: a)
         {
        	 if(i>max)
        	 {   max2=max;
        		 max=i;
        	 }              	 
        	 if(i<min)
        	 {	min2=min;	
        		 min =i;
        	 
        	 }
         }
         System.out.println("Max = "+ max);
         System.out.println("Min = "+ min);
         System.out.println("Max2 = "+ max2);
         System.out.println("Min2 = "+ min2);
         s.close();

	}

}
