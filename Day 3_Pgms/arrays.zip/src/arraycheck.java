
public class arraycheck {
	public static void main(String[] args)
	
	{
		int a[]= new int[4];
		//{1,2,3,4,8};
		for(int i:a)
			System.out.println(i);
			
	}

}
