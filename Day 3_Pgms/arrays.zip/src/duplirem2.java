//Removing duplicate elements (array is not ordered)

import java.util.Scanner;

public class duplirem2 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		int temp;
		int[] a = new int[n];
		
		for(int i=0;i<n;i++)
			a[i]=s.nextInt();
		
		for(int i=0;i<n;i++)
		{
			temp= a[i];
			for(int j=i+1;j<n;j++)
				if(temp==a[j])
				{
					for(int k=j;k<n-1;k++)
						a[k]=a[k+1];
					n--; // variation in 'n' does not resize the array
				}
		}
		//for(int i:a)// this cannot be used as the actual size of array is not changed
		//using this will print the entire array along with the unnecessary numbers.
		for(int i=0;i<n;i++)	
		System.out.println(a[i]+ " ");
		s.close();
	}

}
