// Sorting manually

import java.util.*;
public class sortman {

	public static void main(String[] args) {
		
		int a[]= new int[10];
		int temp;
		Scanner s = new Scanner(System.in);
		
		for(int i=0;i<10;i++)
			a[i] = s.nextInt();
		//Arrays.sort(a);
		for(int i=0;i<9;i++)
			for(int j=i+1;j<10;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]= temp;
				}
			}
		
		for(int i: a)
			System.out.println(i);
		s.close();

	}

}
