import java.util.Scanner;

public class repeatval {
      public static void main(String[] args)
      {   int n;
          int count, k,m,temp,max;
      System.out.println("Enter array size");
      Scanner s = new Scanner (System.in);
      
      n= s.nextInt();
      int[] a= new int[n];
      int[][] freq = new int[2][n]; //2D array to hold the value and its frequency
      
      System.out.println("Enter values");
      for(int i=0;i<n;i++)
      {
    	  a[i] = s.nextInt();
      }
      k=0;
      for(int i=0;i<n;i++)
      {   count=0;
          
    	  temp = a[i];
    	  m=i-1;
    	  while(m>=0)    //to check if temp occurs before
    	  {
    		  if(a[m]!=temp)
    			m--;
    		  else break;
    	  }
    	  if(m!=-1)
    		  continue; //if a[i] already present continue with next iteration
    	  for(int j =i;j<n;j++) //otherwise count its occurance
    	  {
    		  if(a[j]==temp)
    			  count++;
    	  }
    	  freq[0][k]= temp;  //store the value 
    	  freq[1][k]=count;k++; //store the freq
      }
      int lt=0;
      max = freq[1][0];
      for(int i=0;i<k;i++)
    	  if(freq[1][i]>max)
    		  {max = freq[1][i];
    		   lt=i;
    		  }
      System.out.println("Value repeated max times: "+ freq[0][lt]);
    	  
      s.close();
      }

}
