
public class testcases {

	public static void main(String[] args) {
		double y=3.7423;
		double ans = Math.round(y*100)/100.0d;
		System.out.println(ans);
	}

}
