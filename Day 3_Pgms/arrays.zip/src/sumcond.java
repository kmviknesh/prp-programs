import java.util.Scanner;

public class sumcond {

	public static void main(String[] args) {
		int n,k,sum=0;
		Scanner s = new Scanner(System.in);
		n = s.nextInt();
		int[] a = new int[n];
		
		for(int i=0;i<n;i++)
			a[i] = s.nextInt();
		
		for(int i=0;i<n;i++)
		{
			if(a[i]==6)
			{
				k=i+1;
				while(k<n)
				{
					if(a[k]!=7)
						k++;
					else break;
				}
				if(k==n)
					sum+=a[i];
				else i=k;
				
					
			}
			else sum+=a[i];
		}
		System.out.println(sum);
s.close();
	}

}
