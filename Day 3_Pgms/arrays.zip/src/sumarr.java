//Sum and average

import java.util.*;

public class sumarr {

	public static void main(String[] args) {
           int sum=0, avg;
           int a[]=new int[5];
           Scanner s = new Scanner(System.in);
           System.out.println("Enter 5 elements:");
           for(int i=0;i<5;i++)
           {
        	   a[i]= s.nextInt();
           }
           for (int i : a)
           {
        	   sum+=i;
           }
           avg = sum/5;
           System.out.println("Sum = "+ sum);
           System.out.println("Average = "+ avg);
           s.close();
	}

}
