//Removing duplicate(array is ordered)
import java.util.Arrays;
import java.util.Scanner;

public class duplirem {

	public static void main(String[] args)
	{   int temp,j,count=0,n=5;
		int[] a = new int[5];
		Scanner s = new Scanner(System.in);
		for(int i=0;i<5;i++)
			a[i]= s.nextInt();
		Arrays.sort(a);
		
		for( int i=0; i<n;i++)
		{ 
			j=i;count=0;
			temp = a[j];
			while( temp== a[j] && j<n)
			{
				count++;
				j++;
			}
			for(int m=0;m<count-1;m++)
			  {for(int k=i;k<n-1;k++)
			{
				a[k] = a[k+1];
			}
			  }
			n=n-count+1;
		}
		for(int i=0;i<n;i++)
			System.out.print(a[i]+" ");
		s.close();
	}
}
