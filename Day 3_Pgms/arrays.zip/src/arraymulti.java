import java.util.Scanner;

public class arraymulti {

	public static void main(String[] args) {
		int[][] a = new int[2][2];
		Scanner s = new Scanner(System.in);
		System.out.println("Enter");
		for(int i=0;i<2;i++)
			for(int j=0;j<2;j++)
				a[i][j] = s.nextInt();
		for(int i=1;i>=0;i--)
			for(int j=1;j>=0;j--)
				System.out.print(a[i][j]);
s.close();
	}

}
