import java.util.Scanner;

public class repeatval2 {

	public static void main(String[] args) {
		int n; int value=0;
        int count,m,temp,max=0;
    System.out.println("Enter array size");
    Scanner s = new Scanner (System.in);
    
    n= s.nextInt();
    int[] a= new int[n];
     
    
    System.out.println("Enter values");
    for(int i=0;i<n;i++)
    {
  	  a[i] = s.nextInt();
    }
    
    for(int i=0;i<n;i++)
    {   count=0;
        
  	  temp = a[i];
  	  m=i-1;
  	  while(m>=0)    
  	  {
  		  if(a[m]!=temp)
  			m--;
  		  else break;
  	  }
  	  if(m!=-1)
  		  continue; //if a[i] already present continue with next iteration
  	  for(int j =i;j<n;j++) //otherwise count its occurance
  	  {
  		  if(a[j]==temp)
  			  count++;
  	  }
  	  if(count>max)
  		  {
  		  max=count;
  		  value = temp;
  		  }
  	  
  	  
    }
    
    System.out.println("Value repeated max times: "+ value);
  	  
    s.close();

	}

}
