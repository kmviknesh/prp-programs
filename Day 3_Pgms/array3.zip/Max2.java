package lukas3;

import java.util.Arrays;
import java.util.Scanner;

public class Max2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int[] a=new int[10];
		for(int i=0;i<10;i++)
			a[i]=s.nextInt();
		Arrays.sort(a);
		int high=a[0];
		int high2=a[0];
		for(int j=0;j<10;j++)
		{
			if(a[j]>high)
			{
				high2=high;
				high=a[j];
			}
			
		}
		int min=a[0];
		int min2=a[0];
		for(int j=0;j<10;j++)
		{
			if(a[j]<min)
			{
				min=a[j];
				min=min2;
			}
		}
			
		
	
			System.out.println("max 2 elements is "+high2);
			
			System.out.println("min 2 elements is "+min2);
}

	
}
