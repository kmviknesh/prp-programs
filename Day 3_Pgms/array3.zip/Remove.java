package lukas3;
import java.util.Scanner;
import java.util.Arrays;
public class Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a[]=new int[5];
		for(int i=0;i<5;i++)
			a[i]=s.nextInt();
		System.out.println("enter the duplicate elem..");
		int dup=s.nextInt();
		for(int i=0;i<5;i++)
		{
			if(a[i]==dup)
			{
				a[i]=a[i+1];
				a[i+1]=0;
			}
		}
		for(int j:a)
			System.out.println(j);
		

	}

}
