package lukas3;
import java.util.Scanner;

public class Occurence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a[]=new int[5];
		int e[]=new int[5];
		 e[0]=1;e[1]=1;e[2]=1;e[3]=1;e[4]=1;
		for(int i=0;i<10;i++)
			a[i]=s.nextInt();
		for(int i=0;i<5;i++)
		{
			for(int j=i+1;j<5;j++)
			{
				if(a[i]==a[j])
				{
					e[i]++;
				}
			}
		}
		
		System.out.println("");
		

	}

}
