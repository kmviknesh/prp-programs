package lukas3;
import java.util.Scanner;
public class Sumarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int sum=0;
		int a[]=new int[10];
		for(int i=0;i<10;i++)
			a[i]=s.nextInt();
		for(int i=0;i<10;i++)
		{
			if(a[i]==6)
			{
				for(int j=i+1;j<10;j++)
				{
					if(a[j]==7)
					{int k=i;
						do
						{
							a[k]=0;
							k++;
						}while(k!=j+1);
					}
				}
			}
		}
		for(int l:a)
			sum=sum+l;
		System.out.println(sum);
			

	}

}
