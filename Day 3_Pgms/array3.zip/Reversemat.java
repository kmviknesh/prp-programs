package lukas3;
import java.util.Scanner;
import java.util.Arrays;

public class Reversemat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a[][]=new int[2][2];
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
				a[i][j]=s.nextInt();
		}
		
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(" "+a[j][i]);
			
		}
			
		}
	

	}

}
