package lukas3;

import java.util.Scanner;

public class Sum {

	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner s=new Scanner(System.in);
			int[] a=new int[3];
			a[0]=s.nextInt();
			a[1]=s.nextInt();
			a[2]=s.nextInt();
			int sum=0;
		int l=a.length;
			for(int i:a)
			 sum=sum+i;
			int avg=sum/l; 
			System.out.println(sum);
			System.out.println(avg);
	}

}
