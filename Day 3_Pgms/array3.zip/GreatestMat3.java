package lukas3;
import java.util.Scanner;
import java.util.Arrays;
public class GreatestMat3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a[][]=new int[3][3];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				a[i][j]=s.nextInt();
		}
		int max=a[0][0];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(a[i][j]>max)
					max=a[i][j];
			}
		}
		System.out.println(max);
		
		
		

	}

}
