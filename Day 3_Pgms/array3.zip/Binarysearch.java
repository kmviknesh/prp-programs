package lukas3;
import java.util.Scanner;
import java.util.Arrays;
public class Binarysearch {
	public static void main(String[] ar)
	{
		Scanner s=new Scanner(System.in);
		int[] a=new int[5];
		for(int i=0;i<5;i++)
			a[i]=s.nextInt();
		int bin=-1;
		 bin=Arrays.binarySearch(a, 10);
	
		if(bin>=0)
			System.out.println("element in postion "+bin);
		else
			System.out.println("-1");
		
	}

}
