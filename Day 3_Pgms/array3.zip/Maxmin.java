package lukas3;

import java.util.Arrays;
import java.util.Scanner;

public class Maxmin {
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
	int[] a=new int[3];
	a[0]=s.nextInt();
	a[1]=s.nextInt();
	a[2]=s.nextInt();
	
	Arrays.sort(a);

		System.out.println("min is "+a[0]);
		System.out.println("max is "+a[2]);


}
}
